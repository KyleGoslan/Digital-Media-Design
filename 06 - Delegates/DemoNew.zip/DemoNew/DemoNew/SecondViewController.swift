import UIKit

class SecondViewController: UIViewController {
  
  @IBOutlet weak var titleLabel: UILabel!
  @IBOutlet weak var imageView: UIImageView!
  
  var annotation: CustomAnnotation!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    titleLabel.text = annotation.title!
    imageView.image = UIImage(named: annotation.title!)
  }
  
}
