import UIKit
import MapKit

class ViewController: UIViewController {

  @IBOutlet weak var mapView: MKMapView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    mapView.register(CustomAnnotationView.self, forAnnotationViewWithReuseIdentifier: "marker")
    mapView.delegate = self
    
    let firstCoordinate = CLLocationCoordinate2D(latitude: 50.715816, longitude:  -1.875420)
    let firstAnnotation = CustomAnnotation(coordinate: firstCoordinate, title: "Bournemouth")
    mapView.addAnnotation(firstAnnotation)
    
    
    let secondCoordinate = CLLocationCoordinate2D(latitude: 51.509332, longitude:  -0.114764)
    let secondAnnotation = CustomAnnotation(coordinate: secondCoordinate, title: "London")
    mapView.addAnnotation(secondAnnotation)
    
  }
  
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    let vc = segue.destination as! SecondViewController
    vc.annotation = sender as? CustomAnnotation
    vc.delegate = self
  }
  
  
}


extension ViewController: MKMapViewDelegate {


  func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
    performSegue(withIdentifier: "Next", sender: view.annotation!)
  }


  func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
    guard let annotation = annotation as? CustomAnnotation else { return nil }
    let identifier = "marker"
    var view: CustomAnnotationView
    
    if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
      as? CustomAnnotationView {
      dequeuedView.annotation = annotation
      view = dequeuedView
      view.tintColor = annotation.color
    } else {
      view = CustomAnnotationView(annotation: annotation, reuseIdentifier: identifier)
    }
    return view
  }
  
}


extension ViewController: SecondViewControllerDelegate {
 
  func didUpdate(annotation: CustomAnnotation) {
    mapView.removeAnnotation(annotation)
    mapView.addAnnotation(annotation)
  }

  
}

