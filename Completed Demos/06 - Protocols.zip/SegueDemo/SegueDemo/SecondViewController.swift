import UIKit
import MapKit

protocol SecondViewControllerDelegate {
  func didUpdate(annotation: CustomAnnotation)
}

class SecondViewController: UIViewController {
  
  @IBOutlet weak var titleLabel: UILabel!
  @IBOutlet weak var imageView: UIImageView!
  
  var delegate: SecondViewControllerDelegate?
  var annotation: CustomAnnotation!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    titleLabel.text = annotation.title!
    imageView.image = UIImage(named: annotation.title!)
    
  }
  
  @IBAction func changeColor(_ sender: UIButton) {
    
    if sender.tag == 1 {
      annotation.color = .red
    }
    
    if sender.tag == 2 {
      annotation.color = .green
    }
    
    if sender.tag == 3 {
      annotation.color = .purple
    }
  
    delegate?.didUpdate(annotation: annotation)
    
  }
  
}
