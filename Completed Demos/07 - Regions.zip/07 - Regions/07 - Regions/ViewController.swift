import UIKit
import MapKit

class ViewController: UIViewController {
  
  let locationManager = CLLocationManager()
  
  @IBOutlet weak var mapView: MKMapView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    mapView.userTrackingMode = .follow
    
    locationManager.requestAlwaysAuthorization()
    locationManager.delegate = self
    locationManager.startUpdatingLocation()
    
    let coordinate = CLLocationCoordinate2D(latitude: 50.715739, longitude: -1.875466)
    let region = CLCircularRegion(center: coordinate, radius: 300, identifier: "Pier")
    locationManager.startMonitoring(for: region)
    
  }
  
}

extension ViewController: CLLocationManagerDelegate {
  
  func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
    print("Entered: \(region.identifier) region.")
  }
  
  func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
    print("Left: \(region.identifier) region.")
  }
  
}

