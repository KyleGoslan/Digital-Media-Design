import UIKit
import MapKit
import Firebase

class ViewController: UIViewController {
  
  let locationManager = CLLocationManager()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    locationManager.requestAlwaysAuthorization()
    locationManager.delegate = self
    locationManager.startUpdatingLocation()
    watch()
  }
  
  func watch() {
    let ref = Firestore.firestore().collection("locations")
    ref.addSnapshotListener { snapshot, error in
      print(snapshot!.documents)
    }
  }
  
  
  func save(location: CLLocation) {
    let ref = Firestore.firestore().collection("locations").document("YOUR_NAME")
    let geoPoint = GeoPoint(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
    ref.setData(["location": geoPoint])
  }
  
}

extension ViewController:CLLocationManagerDelegate {

  func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    save(location: locations.last!)
  }
  
}
