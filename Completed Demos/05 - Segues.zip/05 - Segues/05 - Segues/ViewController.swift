import UIKit
import MapKit

class ViewController: UIViewController {
  
  @IBOutlet weak var mapView: MKMapView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    mapView.delegate = self
    
    //Get coordinates
    let bournemouthCoord = CLLocationCoordinate2D(latitude: 50.716440, longitude: -1.875655)
    let londonCoord = CLLocationCoordinate2D(latitude: 51.507517, longitude: -0.118965)
    
    //Create some annotations from the coordinates
    let bournemouthAnnotation = CustomAnnotation(coordinate: bournemouthCoord, title: "Bournemouth")
    let londonAnnotation = CustomAnnotation(coordinate: londonCoord, title: "London")
    
    //Add annotations to the maps as an array
    mapView.addAnnotations([londonAnnotation, bournemouthAnnotation])
    
  }
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    let vc = segue.destination as! SecondViewController
    vc.annotation = sender as? CustomAnnotation
  }

}

extension ViewController: MKMapViewDelegate {
  
  func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
    guard let annotation = view.annotation as? CustomAnnotation else { return }
    performSegue(withIdentifier: "Next", sender: annotation)
    mapView.deselectAnnotation(annotation, animated: true)
  }
  
}
