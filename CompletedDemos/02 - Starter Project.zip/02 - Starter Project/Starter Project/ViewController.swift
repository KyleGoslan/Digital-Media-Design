import UIKit

class ViewController: UIViewController {
  
  let me = Person(name: "Grace", age: 22)

  @IBOutlet weak var label: UILabel!

  override func viewDidLoad() {
    super.viewDidLoad()
  }

  @IBAction func button(_ sender: Any) {
    me.haveBirthday()
    label.text = "My name is \(me.name), I am \(me.age) from Bournemouth"

  }
  
  
}

