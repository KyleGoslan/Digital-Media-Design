import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController {

    let locationManager = CLLocationManager()

    var latSlider: CLLocationDegrees = 0
    var longSlider: CLLocationDegrees = 0
    
    @IBOutlet var mapView: MKMapView!
    
    @IBOutlet var latLabel: UILabel!
    @IBOutlet var longLabel: UILabel!
  
  
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
  
  
  @IBAction func latSlider(_ sender: UISlider) {
    latLabel.text = String(sender.value)
    latSlider = CLLocationDegrees(sender.value)
  }
  
  @IBAction func longSlider(_ sender: UISlider) {
    longLabel.text = String(sender.value)
    longSlider = CLLocationDegrees(sender.value)
  }
  
  
  
  
  
    @IBAction func getAddressButton(_ sender: Any) {
        let span = MKCoordinateSpan(latitudeDelta: 2, longitudeDelta: 2)
        let region = MKCoordinateRegion(center:CLLocationCoordinate2D(latitude:
            latSlider, longitude: longSlider),span: span)
        mapView.setRegion(region, animated: true)
        
      let annotation = CustomAnnotation(coordinate: CLLocationCoordinate2D.init(latitude: latSlider, longitude: longSlider), title: "New Location")
        mapView.addAnnotation(annotation)
        
    }

}




