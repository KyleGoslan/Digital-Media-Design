import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var errorLabel: UILabel!
  @IBOutlet weak var confirmPasswordTextField: UITextField!
  @IBOutlet weak var usernameTextField: UITextField!
  @IBOutlet weak var passwordTextField: UITextField!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    errorLabel.isHidden = true
    usernameTextField.text = "grace"
    passwordTextField.text = "password"
    
    
    
  }
  
  @IBAction func goButton(_ sender: UIButton) {
    guard let username = usernameTextField.text, let password = passwordTextField.text, let confirmPassowrd = confirmPasswordTextField.text else {
               return
    }
    
    if password == confirmPassowrd {
      errorLabel.isHidden = false
      errorLabel.text = "passwords are the same"
    } else {
      errorLabel.isHidden = false
      errorLabel.text = "Try again! passwords dont match"

    }
    
//    guard password == confirmPassword.text else {
//          errorLabel.isHidden = false
//          errorLabel.text = "Passwords don't match"
//        return
//    }
//
//    guard password != confirmPassword.text else {
//          errorLabel.isHidden = false
//          errorLabel.text = "Yay - they match!"
//        return
//    }
    
  }
  
}



