import UIKit
import MapKit

class ViewController: UIViewController {

  @IBOutlet weak var mapView: MKMapView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    //Create an annoation object.
    let myAnnotation = MKPointAnnotation()
    
    //Set the annoations coordinate by creating a CLLocationCoordinate2D object.
    myAnnotation.coordinate = CLLocationCoordinate2D(latitude: 50.753019, longitude: -1.930140)
    
    //Optionally give the annotation a title.
    myAnnotation.title = "Hello World"
    
    //Finally add the annotation to the map view.
    mapView.addAnnotation(myAnnotation)
    
    
  }

}
