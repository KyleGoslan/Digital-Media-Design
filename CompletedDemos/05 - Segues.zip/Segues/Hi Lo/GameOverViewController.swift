import UIKit

class GameOverViewConroller: UIViewController {
  
  
  
  @IBOutlet weak var scoreLabel: UILabel!
  
  var score = 0 
  
  override func viewDidLoad() {
    super.viewDidLoad()
    scoreLabel.text = "\(score)"
    
  }
  
  
}


