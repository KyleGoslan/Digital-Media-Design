//
//  ViewController.swift
//  FirebaseStarter
//
//  Created by Kyle Goslan on 20/11/2019.
//  Copyright © 2019 Kyle Goslan. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

  @IBOutlet weak var mapView: MKMapView!
  
  let locationManager = CLLocationManager()
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    locationManager.requestAlwaysAuthorization()
    locationManager.delegate = self
    locationManager.startUpdatingLocation()
    
  }
  
  // Save the users location to the server
  func updateUser(coordinate: CLLocationCoordinate2D) {

  }
  
  // Refresh the map with new data
  func loadNewData() {
    
  }
  
  
}

extension ViewController: CLLocationManagerDelegate {
  
  func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    
    guard let location = locations.last else { return }
    
    print(location)
    
  }
  
}
