//
//  ViewController.swift
//  Workshop 2
//
//  Created by Grace Miller on 03/10/2019.
//  Copyright © 2019 Grace Miller. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
  @IBOutlet weak var nameLabel: UILabel!
  
  let me = Person(name: "Grace", age: 23)

  override func viewDidLoad() {
    super.viewDidLoad()
    nameLabel.text = me.name
  
  }

  
}

