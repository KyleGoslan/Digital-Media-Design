import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var opacitySlider: UISlider!
  @IBOutlet weak var imageView: UIImageView!
  @IBOutlet weak var segmentedController: UISegmentedControl!
  
  
  override func viewDidLoad() {
    super.viewDidLoad()
    imageView.image = UIImage.init(named: "sky")

  }


  @IBAction func segmentController(_ sender: UISegmentedControl) {
    switch segmentedController.selectedSegmentIndex
       {
       case 0:
        imageView.isHidden = false
       case 1:
        imageView.isHidden = true
       default:
           break
       }
 

  }
  
  @IBAction func redButton(_ sender: Any) {
    imageView.image = UIImage.init(named: "desert")
  }
  
  @IBAction func greenButton(_ sender: Any) {
    imageView.image = UIImage.init(named: "space")

  }
  
  @IBAction func purpleButton(_ sender: Any) {
    imageView.image = UIImage.init(named: "sky")


  }
  
  
  @IBAction func opacitySlider(_ sender: UISlider) {
    imageView.alpha = CGFloat(sender.value)
  }
  
}

