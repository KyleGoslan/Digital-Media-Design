//
//  ViewController.swift
//  FirebaseStarter
//
//  Created by Kyle Goslan on 20/11/2019.
//  Copyright © 2019 Kyle Goslan. All rights reserved.
//

import UIKit
  
class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
  }
  
}

