import UIKit

class GameViewController: UIViewController {

  @IBOutlet weak var targetLabel: UILabel!
  @IBOutlet weak var scoreLabel: UILabel!
  
  var target = 0
  var newTarget = 0
  var score = 0
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    resetGame()
  }

  func generateRandomNumber() {
    newTarget = Int.random(in: 0...100)
  }

  func correctGuess() {
    score += 1
    scoreLabel.text = "Score: \(score)"
    target = newTarget
    targetLabel.text = "\(target)"
  }
  
  func wrongGuess() {
    performSegue(withIdentifier: "GameOver", sender: nil)
    resetGame()
  }
  
  
  
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    let gameOverViewController = segue.destination as! GameOverViewConroller
    gameOverViewController.score = score
  }
  
  
  
  @IBAction func guessHigher(_ sender: Any) {
    generateRandomNumber()
    if newTarget > target {
      correctGuess()
    } else {
      wrongGuess()  
    }
  }
  
  @IBAction func guessLower(_ sender: Any) {
    generateRandomNumber()
    if newTarget < target {
      correctGuess()
    } else {
      wrongGuess()
    }
  }
  
  func resetGame() {
    score = 0
    target = 0
    newTarget = 0
    targetLabel.text = "\(target)"
    scoreLabel.text = "Score: \(score)"
  }
  
}

