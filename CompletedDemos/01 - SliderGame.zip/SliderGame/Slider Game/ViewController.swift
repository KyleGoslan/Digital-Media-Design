import UIKit

class ViewController: UIViewController {

  @IBOutlet weak var targetLabel: UILabel!
  
  @IBOutlet weak var slider: UISlider!
  
  var target = 0
  
  override func viewDidLoad() {
    super.viewDidLoad()
    generateTarget()
  }

  func generateTarget() {
    slider.value = 0
    target = Int.random(in: 0...100)
    targetLabel.text = "\(target)"
  }

  @IBAction func guess(_ sender: Any) {
    let guessNumber = slider.value
    let result = Int(guessNumber) - target
    
    if abs(result) < 4 {
      generateTarget()
    }
    
  }
  
}

